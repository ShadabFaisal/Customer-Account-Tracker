import React from "react";

import "../stylesheets/NavbarStyles.css";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();

  const redirectToSignIn = () => {
    localStorage.clear();
    navigate("/"); // Redirect to the sign-in page
  };

  return (
    <nav className="navbar navbar-expand-sm bg-dark navbar-dark">
      <div className="container-fluid">
        <Link className="navbar-brand" href="/">
        Trackify
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#collapsibleNavbar"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="collapsibleNavbar">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" href="/">
                Home
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/about-page">
                About
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link" to="/contact-page">
                Contact
              </Link>
            </li>
          </ul>
        </div>

        <button
          type="button"
          className="btn btn-secondary px-4 register-btn"
          onClick={redirectToSignIn}
        >
          Log Out
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
