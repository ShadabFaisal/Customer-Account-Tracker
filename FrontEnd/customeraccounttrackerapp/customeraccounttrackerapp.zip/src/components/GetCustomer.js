import React, {useState } from 'react'
import { Link } from 'react-router-dom';
import CustomerService from '../services/CustomerService';
import CustomerCard from './CustomerCard';
import Navbar from './Navbar';
import '../stylesheets/CardStyles.css'
import Footer from '../components/Footer'

const GetCustomer = () => {

  const [customerId, setCustomerId] = useState("");
  const [data, setData] = useState();
  const getCustomer = (customerId) => {
    CustomerService.getCustomerById(customerId).then(res => {
      console.log(res.data);
      let cust = res.data;
      setData(cust);
    })
    setCustomerId("")
  }

  return (
    <div className='customer-card' >
      <Navbar />
      <div className='py-5'>
        <form className='mx-auto col-10 col-md-8 col-lg-5 get-customer'>
          <h4>Search Customer Details By Id</h4>
          <div className="mb-3">
            <label htmlFor="customerId" className="form-label">
              Customer Id
            </label>
            <input
              type="number"
              className="form-control"
              id="customerId"
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
              placeholder="Enter Customer Id"
            />

          </div>
          <Link className='btn btn-primary' onClick={() => getCustomer(customerId)}>Get Customer</Link>
        </form>
      {data && <CustomerCard customer={data} />}
      </div>
      <Footer/>
    </div>
  )
}

export default GetCustomer
